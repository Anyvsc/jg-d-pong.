let xBolinha = 20;
let yBolinha = 20;
let velocidadeXBolinha = 2;
let velocidadeYBolinha = 2;
let diametro = 20;
let raio = diametro / 2;
function setup() {
  createCanvas(600, 400);
}
function draw() {
  background("black");
  xBolinha = xBolinha + velocidadeXBolinha;

  if (xBolinha > width || xBolinha < 0) {
    velocidadeXBolinha *= -1;
  }
  circle(xBolinha, yBolinha, diametro);
}
function mostraBolinha() {
  circle(xBolinha, yBolinha, diametro);
}
function movimentaBolinha() {
  xBolinha = xBolinha + velocidadeXBolinha;
  yBolinha = yBolinha + velocidadeYBolinha;
}
function verificaColisaoBorda() {
  if (xBolinha + raio > width || xBolinha - raio < 0) {
    velocidadeXBolinha *= -1;
  }
  if (yBolinha + raio > height || yBolinha - raio < 0) {
    velocidadeYBolinha *= -1;
  }
}
